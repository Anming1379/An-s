@echo off
cd /d "%~dp0"

:: Register DLLs
regsvr32.exe /s ILWASAPI2ASIO.DLL
regsvr32.exe /s ILWASAPI2ASIO_x64.DLL

:: Registry for 64-bit Apps
set "REG64=HKLM\SOFTWARE\ASIO\FL Studio ASIO"
reg add "%REG64%" /v "Driver" /t REG_SZ /d "%~dp0ILWASAPI2ASIO_x64.DLL" /f
reg add "%REG64%" /v "Description" /t REG_SZ /d "FL Studio ASIO" /f
reg add "%REG64%" /v "CLSID" /t REG_SZ /d "{188135E1-7171-3434-854F-01A3C71F3DF9}" /f

:: Registry for 32-bit Apps (WOW6432Node)
set "REG32=HKLM\SOFTWARE\WOW6432Node\ASIO\FL Studio ASIO"
reg add "%REG32%" /v "Driver" /t REG_SZ /d "%~dp0ILWASAPI2ASIO.DLL" /f
reg add "%REG32%" /v "Description" /t REG_SZ /d "FL Studio ASIO" /f
reg add "%REG32%" /v "CLSID" /t REG_SZ /d "{188135E1-7171-3434-854F-01A3C71F3DF9}" /f

echo Done.
pause