@echo off
reg delete "HKLM\SOFTWARE\ASIO\FL Studio ASIO" /f
reg delete "HKLM\SOFTWARE\WOW6432Node\ASIO\FL Studio ASIO" /f
echo Registry cleaned.
pause